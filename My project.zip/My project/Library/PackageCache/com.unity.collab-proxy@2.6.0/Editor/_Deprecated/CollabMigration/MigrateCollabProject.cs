﻿using System.ComponentModel;

namespace Unity.PlasticSCM.Editor.CollabMigration
{
	// Internal usage. This isn't a public API.
	[EditorBrowsable(EditorBrowsableState.Never)]
    public static class MigrateCollabProject
    {
    }
}
